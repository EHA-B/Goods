const path = require('path');
const dbmanager = require(path.join(__dirname, '../database/databaseManager'));

class StockAdjustmentController {

    async createStockAdjustment(input) {
        if (!input || !input.product_id) {
            const err = new Error('product_id is required');
            err.code = 'VALIDATION_ERROR';
            throw err;
        }
        const db = await dbmanager.init();
        const sql = `
            INSERT INTO stock_adjustments (product_id, stock_batch_id, quantity, quantity_before, quantity_after, reason, notes, created_at, updated_at)
            VALUES (?,?,?,?,?,?,?, datetime('now'), datetime('now'))
        `;
        const id = await new Promise((resolve, reject) => {
            db.run(sql, [
                input.product_id ?? null,
                input.stock_batch_id ?? null,
                input.quantity ?? null,
                input.quantity_before ?? 0,
                input.quantity_after ?? 0,
                input.reason ?? null,
                input.notes ?? null
            ], function (err) {
                if (err) return reject(err);
                resolve(this.lastID);
            });
        });
        return this.getStockAdjustment(id);
    }

    async getStockAdjustment(id) {
        if (!id) throw { code: 'VALIDATION_ERROR', message: 'ID is required' };
        const db = await dbmanager.init();
        return await new Promise((resolve, reject) => {
            db.get(
                `SELECT sa.*, COALESCE(sa.product_id, sb.product_id) AS product_id
                 FROM stock_adjustments sa
                 LEFT JOIN stock_batches sb ON sb.id = sa.stock_batch_id
                 WHERE sa.id = ?`,
                [id],
                (err, row) => {
                    if (err) return reject(err);
                    if (!row) return reject({ code: 'NOT_FOUND', message: 'StockAdjustment not found' });
                    resolve(row);
                }
            );
        });
    }

    async getAllStockAdjustments() {
        const db = await dbmanager.init();
        return await new Promise((resolve, reject) => {
            db.all(
                `SELECT sa.*, COALESCE(sa.product_id, sb.product_id) AS product_id
                 FROM stock_adjustments sa
                 LEFT JOIN stock_batches sb ON sb.id = sa.stock_batch_id
                 ORDER BY sa.id DESC`,
                [],
                (err, rows) => {
                    if (err) return reject(err);
                    resolve(rows);
                }
            );
        });
    }

    async updateStockAdjustment(id, input) {
        if (!id) throw { code: 'VALIDATION_ERROR', message: 'ID is required' };

        const mapping = {
            product_id: 'product_id',
            stock_batch_id: 'stock_batch_id',
            quantity: 'quantity',
            quantity_before: 'quantity_before',
            quantity_after: 'quantity_after',
            reason: 'reason',
            notes: 'notes'
        };
        const sets = [];
        const params = [];

        for (const key of Object.keys(mapping)) {
            if (input && Object.prototype.hasOwnProperty.call(input, key)) {
                sets.push(`${mapping[key]} = ?`);
                params.push(input[key] ?? null);
            }
        }

        if (sets.length === 0) {
            const err = new Error('No fields provided to update');
            err.code = 'VALIDATION_ERROR';
            throw err;
        }
        sets.push(`updated_at = datetime('now')`);
        const sql = `UPDATE stock_adjustments SET ${sets.join(', ')} WHERE id = ?`;
        params.push(id);

        const db = await dbmanager.init();
        const info = await new Promise((resolve, reject) => {
            db.run(sql, params, function (err) {
                if (err) return reject(err);
                resolve({ changes: this.changes });
            });
        });

        if (!info || info.changes === 0) throw { code: 'NOT_FOUND', message: 'StockAdjustment not found' };

        return this.getStockAdjustment(id);
    }

    async deleteStockAdjustment(id) {
        if (!id) throw { code: 'VALIDATION_ERROR', message: 'ID is required' };
        const db = await dbmanager.init();
        const info = await new Promise((resolve, reject) => {
            db.run(`DELETE FROM stock_adjustments WHERE id = ?`, [id], function (err) {
                if (err) return reject(err);
                resolve({ changes: this.changes });
            });
        });
        if (!info || info.changes === 0) throw { code: 'NOT_FOUND', message: 'StockAdjustment not found' };
        return { success: true, message: 'StockAdjustment deleted successfully' };
    }
}

module.exports = new StockAdjustmentController();
