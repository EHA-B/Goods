const path = require('path');
const dbmanager = require(path.join(__dirname, '../database/databaseManager'));

const get = (db, sql, params=[]) => new Promise((resolve,reject)=>db.get(sql,params,(e,r)=>e?reject(e):resolve(r)));
const all = (db, sql, params=[]) => new Promise((resolve,reject)=>db.all(sql,params,(e,r)=>e?reject(e):resolve(r||[])));

const isIsoDate = (value) => typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value);

/** Accepts an optional { fromDate, toDate } range (YYYY-MM-DD) and drops invalid values. */
function normalizeStatementRange(range) {
  const fromDate = isIsoDate(range?.fromDate) ? range.fromDate : null;
  const toDate = isIsoDate(range?.toDate) ? range.toDate : null;
  return { fromDate, toDate };
}

function buildDateRangeSql(column, fromDate, toDate) {
  let sql = '';
  const params = [];
  if (fromDate) { sql += ` AND date(${column}) >= date(?)`; params.push(fromDate); }
  if (toDate) { sql += ` AND date(${column}) <= date(?)`; params.push(toDate); }
  return { sql, params };
}

class PrintController {
  async getPaymentDocument(id) {
    const db = await dbmanager.init();
    const payment = await get(db, `SELECT p.*, c.name cashbox_name,
      CASE WHEN p.payment_type IN ('sale','sale_reversal') THEN cu.name ELSE s.name END party_name,
      CASE WHEN p.payment_type IN ('sale','sale_reversal') THEN si.invoice_number ELSE pi.invoice_number END invoice_number
      FROM payments p
      LEFT JOIN cashboxes c ON c.id=p.cashbox_id
      LEFT JOIN sale_invoices si ON p.payment_type IN ('sale','sale_reversal') AND si.id=p.invoice_id
      LEFT JOIN purchase_invoices pi ON p.payment_type IN ('purchase','purchase_reversal') AND pi.id=p.invoice_id
      LEFT JOIN customers cu ON p.payment_type IN ('sale','sale_reversal') AND cu.id=p.party_id
      LEFT JOIN suppliers s ON p.payment_type IN ('purchase','purchase_reversal') AND s.id=p.party_id
      WHERE p.id=?`, [id]);
    if (!payment) throw Object.assign(new Error('Payment not found'), {code:'NOT_FOUND'});
    return payment;
  }

  async getTransactionDocument(id) {
    const db = await dbmanager.init();
    const row = await get(db, `SELECT t.*, tc.name category_name, c.name cashbox_name, c.currency cashbox_currency
      FROM transactions t LEFT JOIN transaction_categories tc ON tc.id=t.category_id
      LEFT JOIN cashboxes c ON c.id=t.cashbox_id WHERE t.id=?`, [id]);
    if (!row) throw Object.assign(new Error('Transaction not found'), {code:'NOT_FOUND'});
    return row;
  }

  async getTransferDocument(groupId) {
    const db = await dbmanager.init();
    const rows = await all(db, `SELECT ct.*, c.name cashbox_name, c.currency cashbox_currency
      FROM cashbox_transactions ct LEFT JOIN cashboxes c ON c.id=ct.cashbox_id
      WHERE ct.transfer_group_id=? ORDER BY ct.id`, [groupId]);
    if (!rows.length) throw Object.assign(new Error('Transfer not found'), {code:'NOT_FOUND'});
    return { transfer_group_id: groupId, movements: rows };
  }

  async getCustomerStatement(id, range = {}) {
    const db = await dbmanager.init();
    const party = await get(db, `SELECT * FROM customers WHERE id=?`, [id]);
    if (!party) throw Object.assign(new Error('Customer not found'), {code:'NOT_FOUND'});
    const { fromDate, toDate } = normalizeStatementRange(range);
    const invoiceRange = buildDateRangeSql('invoice_date', fromDate, toDate);
    const paymentRange = buildDateRangeSql('p.payment_date', fromDate, toDate);
    const invoices = await all(db, `SELECT id, invoice_number, invoice_date, total, paid_amount, remaining_amount, status, currency, exchange_rate,
      total * COALESCE(exchange_rate,1) amount_base FROM sale_invoices WHERE customer_id=?${invoiceRange.sql} ORDER BY invoice_date,id`, [id, ...invoiceRange.params]);
    const payments = await all(db, `SELECT p.*, c.name cashbox_name FROM payments p LEFT JOIN cashboxes c ON c.id=p.cashbox_id
      WHERE p.payment_type IN ('sale','sale_reversal') AND p.party_id=?${paymentRange.sql} ORDER BY p.payment_date,p.id`, [id, ...paymentRange.params]);
    return { party, invoices, payments, balance: Number(party.balance||0), statement_type:'customer', from_date: fromDate, to_date: toDate };
  }

  async getSupplierStatement(id, range = {}) {
    const db = await dbmanager.init();
    const party = await get(db, `SELECT * FROM suppliers WHERE id=?`, [id]);
    if (!party) throw Object.assign(new Error('Supplier not found'), {code:'NOT_FOUND'});
    const { fromDate, toDate } = normalizeStatementRange(range);
    const invoiceRange = buildDateRangeSql('invoice_date', fromDate, toDate);
    const paymentRange = buildDateRangeSql('p.payment_date', fromDate, toDate);
    const invoices = await all(db, `SELECT id, invoice_number, invoice_date, total, paid_amount, remaining_amount, status, currency, exchange_rate,
      total * COALESCE(exchange_rate,1) amount_base FROM purchase_invoices WHERE supplier_id=?${invoiceRange.sql} ORDER BY invoice_date,id`, [id, ...invoiceRange.params]);
    const payments = await all(db, `SELECT p.*, c.name cashbox_name FROM payments p LEFT JOIN cashboxes c ON c.id=p.cashbox_id
      WHERE p.payment_type IN ('purchase','purchase_reversal') AND p.party_id=?${paymentRange.sql} ORDER BY p.payment_date,p.id`, [id, ...paymentRange.params]);
    return { party, invoices, payments, balance: Number(party.balance||0), statement_type:'supplier', from_date: fromDate, to_date: toDate };
  }

  async getCashboxStatement(id) {
    const db = await dbmanager.init();
    const cashbox = await get(db, `SELECT * FROM cashboxes WHERE id=?`, [id]);
    if (!cashbox) throw Object.assign(new Error('Cashbox not found'), {code:'NOT_FOUND'});
    const movements = await all(db, `SELECT * FROM cashbox_transactions WHERE cashbox_id=? ORDER BY transaction_date,id`, [id]);
    return { cashbox, movements };
  }

  async getConsignmentDocument(purchaseId) {
    const db = await dbmanager.init();
    const settlement = await get(db, `SELECT cs.*, pi.invoice_number, pi.currency, pi.exchange_rate, s.name supplier_name, c.name cashbox_name
      FROM consignment_settlements cs JOIN purchase_invoices pi ON pi.id=cs.purchase_invoice_id
      LEFT JOIN suppliers s ON s.id=pi.supplier_id LEFT JOIN cashboxes c ON c.id=cs.cashbox_id
      WHERE cs.purchase_invoice_id=? ORDER BY cs.id DESC LIMIT 1`, [purchaseId]);
    if (!settlement) throw Object.assign(new Error('Settlement not found'), {code:'NOT_FOUND'});
    const items = await all(db, `SELECT csi.*, p.name product_name FROM consignment_settlement_items csi
      LEFT JOIN products p ON p.id=csi.product_id WHERE csi.settlement_id=? ORDER BY csi.id`, [settlement.id]);
    return { settlement, items };
  }
}
module.exports = new PrintController();
