import knex, { Knex } from 'knex';
import path from 'path';
import { app } from 'electron';

// Import migrations and seeds statically so Vite bundles them
import * as initialSchema from './migrations/20250101000000_initial_schema';
import * as consignmentMigration from './migrations/20260728141424_consignment_support';
import * as productCodeMigration from './migrations/20260731190000_add_product_code';
import * as optionalProductCodeMigration from './migrations/20260731210000_make_product_code_optional';
import * as quantityBeforeAfterMigration from './migrations/20260801135327_add_quantity_before_after_to_stock_adjustments';
import * as cashboxAccountingHardening from './migrations/20260803_cashbox_accounting_hardening';
import * as singleUserAuthMigration from './migrations/20260803210000_single_user_auth';
import * as sales_purchases_hardening from './migrations/20260804_sales_purchases_hardening';
import * as consignmentSettlementsMigration from './migrations/20260804130000_consignment_settlements';
import * as financialTransactionsHardening from './migrations/20260804140000_financial_transactions_hardening';
import * as purchaseRuntimeCompatibility from './migrations/20260804170000_purchase_runtime_compatibility';
import * as saleRuntimeCompatibility from './migrations/20260804200000_sale_runtime_compatibility';
import * as paymentPartyOptionalMigration from './migrations/20260804210000_make_payment_party_optional';
import * as invoiceCurrencyMigration from './migrations/20260805144600_add_currency_to_invoices';
import * as multiCurrencyHardeningMigration from './migrations/20260805160000_multi_currency_hardening';
import * as notificationsCenterMigration from './migrations/20260805203000_notifications_center';
import * as notificationsLifecycleHardeningMigration from './migrations/20260805214500_notifications_lifecycle_hardening';
import * as consignmentExpectedPurchasePriceMigration from './migrations/20260807233500_consignment_expected_purchase_price';
import * as consignmentPrepaidAmountMigration from './migrations/20260809000000_consignment_prepaid_amount';
import * as addWorkersTableMigration from './migrations/20260809100000_add_workers_table';
import * as m20260810113000_link_worker_payments_financial_transactions from './migrations/20260810113000_link_worker_payments_financial_transactions';
import * as m20260814000000_consignment_settlement_monetary_values from './migrations/20260814000000_consignment_settlement_monetary_values';
import * as m20260814000001_make_transaction_cashbox_nullable from './migrations/20260814000001_make_transaction_cashbox_nullable';
import * as paymentInvoiceOptionalMigration from './migrations/20260823120000_make_payment_invoice_optional';
import * as cashboxesSeed from './seeds/01_cashboxes';
import * as usersSeed from './seeds/02_users';
import * as addPurchaseExtraCostsMigration from './migrations/20260827000000_add_purchase_extra_costs';
import * as addPurchaseExtraCostResponsibilityMigration from './migrations/20260831000000_add_purchase_extra_cost_responsibility';
import * as unifiedStockAndManualConsignmentMigration from './migrations/20261104180000_unified_stock_and_manual_consignment';
import * as addStockWeightToInvoiceItemsMigration from './migrations/20261105210000_add_stock_weight_to_invoice_items';

let knexInstance: Knex | null = null;

class MigrationSource {
  async getMigrations() {
    return Promise.resolve([  
      '20250101000000_initial_schema.ts',
      '20260728141424_consignment_support.ts',
      '20260731190000_add_product_code.ts',
      '20260731210000_make_product_code_optional.ts',
      '20260801135327_add_quantity_before_after_to_stock_adjustments.ts',
      '20260803_cashbox_accounting_hardening.ts',
      '20260803210000_single_user_auth.ts',
      '20260804_sales_purchases_hardening.ts',
      '20260804130000_consignment_settlements.ts',
      '20260804140000_financial_transactions_hardening.ts',
      '20260804170000_purchase_runtime_compatibility.ts',
      '20260804200000_sale_runtime_compatibility.ts',
      '20260804210000_make_payment_party_optional.ts',
      '20260805144600_add_currency_to_invoices.ts',
      '20260805160000_multi_currency_hardening.ts',
      '20260805203000_notifications_center.ts',
      '20260805214500_notifications_lifecycle_hardening.ts',
      '20260807233500_consignment_expected_purchase_price.ts',
      '20260809000000_consignment_prepaid_amount.ts',
      '20260809100000_add_workers_table.ts',
      '20260810113000_link_worker_payments_financial_transactions.ts',
      '20260814000000_consignment_settlement_monetary_values.ts',
      '20260814000001_make_transaction_cashbox_nullable.ts',
      '20260823120000_make_payment_invoice_optional.ts',
      '20260827000000_add_purchase_extra_costs.ts',
      '20260831000000_add_purchase_extra_cost_responsibility.ts',
      '20261104180000_unified_stock_and_manual_consignment.ts',
      '20261105210000_add_stock_weight_to_invoice_items.ts',
    ]);
  }
  getMigrationName(migration: string) {
    return migration;
  }
  async getMigration(migration: string) {
    if (migration === '20250101000000_initial_schema.ts') {
      return initialSchema;
    }
    if (migration === '20260728141424_consignment_support.ts') {
      return consignmentMigration;
    }
    if (migration === '20260731190000_add_product_code.ts') {
      return productCodeMigration;
    }
    if (migration === '20260731210000_make_product_code_optional.ts') {
      return optionalProductCodeMigration;
    }
    if (migration === '20260801135327_add_quantity_before_after_to_stock_adjustments.ts') {
      return quantityBeforeAfterMigration;
    }
    if (migration === '20260803_cashbox_accounting_hardening.ts') {
      return cashboxAccountingHardening;
    }
    if (migration === '20260803210000_single_user_auth.ts') {
      return singleUserAuthMigration;
    }
    if (migration === '20260804130000_consignment_settlements.ts') {
      return consignmentSettlementsMigration;
    }
    if (migration === '20260804140000_financial_transactions_hardening.ts') {
      return financialTransactionsHardening;
    }
    if (migration === '20260804170000_purchase_runtime_compatibility.ts') {
      return purchaseRuntimeCompatibility;
    }
    if (migration === '20260804200000_sale_runtime_compatibility.ts') {
      return saleRuntimeCompatibility;
    }
    if (migration === '20260804210000_make_payment_party_optional.ts') {
      return paymentPartyOptionalMigration;
    }
    if (migration === '20260805144600_add_currency_to_invoices.ts') {
      return invoiceCurrencyMigration;
    }
    if (migration === '20260805160000_multi_currency_hardening.ts') {
      return multiCurrencyHardeningMigration;
    }
    if (migration === '20260805203000_notifications_center.ts') {
      return notificationsCenterMigration;
    }
    if (migration === '20260805214500_notifications_lifecycle_hardening.ts') {
      return notificationsLifecycleHardeningMigration;
    }
    if (migration === '20260807233500_consignment_expected_purchase_price.ts') {
      return consignmentExpectedPurchasePriceMigration;
    }
    if (migration === '20260809000000_consignment_prepaid_amount.ts') {
      return consignmentPrepaidAmountMigration;
    }
    if (migration === '20260809100000_add_workers_table.ts') {
      return addWorkersTableMigration;
    }
    if (migration === '20260810113000_link_worker_payments_financial_transactions.ts') {
      return { name: '20260810113000_link_worker_payments_financial_transactions.ts', up: m20260810113000_link_worker_payments_financial_transactions.up, down: m20260810113000_link_worker_payments_financial_transactions.down };
    }
    if (migration === '20260814000000_consignment_settlement_monetary_values.ts') {
      return { name: '20260814000000_consignment_settlement_monetary_values.ts', up: m20260814000000_consignment_settlement_monetary_values.up, down: m20260814000000_consignment_settlement_monetary_values.down };
    }
    if (migration === '20260814000001_make_transaction_cashbox_nullable.ts') {
      return { name: '20260814000001_make_transaction_cashbox_nullable.ts', up: m20260814000001_make_transaction_cashbox_nullable.up, down: m20260814000001_make_transaction_cashbox_nullable.down };
    }
    if (migration === '20260823120000_make_payment_invoice_optional.ts') {
      return paymentInvoiceOptionalMigration;
    }
    if (migration === '20260804_sales_purchases_hardening.ts') {
      return sales_purchases_hardening;
    }
    if (migration === '20260827000000_add_purchase_extra_costs.ts') {
      return addPurchaseExtraCostsMigration;
    }
    if (migration === '20260831000000_add_purchase_extra_cost_responsibility.ts') {
      return addPurchaseExtraCostResponsibilityMigration;
    }
    if (migration === '20261104180000_unified_stock_and_manual_consignment.ts') {
      return unifiedStockAndManualConsignmentMigration;
    }
    if (migration === '20261105210000_add_stock_weight_to_invoice_items.ts') {
      return addStockWeightToInvoiceItemsMigration;
    }
    throw new Error(`Migration ${migration} not found`);
  }
}

class SeedSource {
  async getSeeds() {
    return Promise.resolve(['01_cashboxes.ts', '02_users.ts']);
  }
  async getSeed(seed: string) {
    if (seed === '01_cashboxes.ts') return cashboxesSeed;
    if (seed === '02_users.ts') return usersSeed;
    throw new Error(`Seed ${seed} not found`);
  }
}

export function getKnex(): Knex {
  if (!knexInstance) {
    throw new Error('Knex not initialized. Call initKnex() first.');
  }
  return knexInstance;
}

export async function initKnex(): Promise<void> {
  const dbPath = path.join(app.getPath('userData'), 'farmer-market.db');

  knexInstance = knex({
    client: 'sqlite3',
    connection: {
      filename: dbPath,
    },
    useNullAsDefault: true,
    migrations: {
      migrationSource: new MigrationSource(),
      tableName: 'knex_migrations',
    },
    seeds: {
      seedSource: new SeedSource(),
    },
    pool: {
      afterCreate: (conn: any, done: any) => {
        conn.run('PRAGMA foreign_keys = ON', done);
      },
    },
  });

  (global as any).__knex = knexInstance;

  console.log(`📁 Database location: ${dbPath}`);
}

export async function closeKnex(): Promise<void> {
  if (knexInstance) {
    await knexInstance.destroy();
    knexInstance = null;
    (global as any).__knex = null;
  }
}
