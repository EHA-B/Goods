'use strict';
/**
 * paymentController.js — Business-safe payment operations.
 *
 * Non-negotiable rules (per execution plan):
 *  - No generic createPayment / updatePayment / deletePayment exposed to the renderer.
 *  - All mutations are atomic database transactions.
 *  - Cashbox balance is updated through direct SQL (same transaction — no IPC round-trip).
 *  - Party (customer/supplier) balance is updated atomically.
 *  - Reversal creates an opposite record; original is preserved in history.
 */

const path = require('path');
const dbmanager = require(path.join(__dirname, '../database/databaseManager'));
const {
    validatePositiveAmount,
    normalizeAmount,
    validateDate,
    calculatePaymentState,
    logActivity,
    dbRun,
    dbGet,
    dbAll,
} = require('./utils/invoiceUtils');
const {
    normalizeCurrency,
    normalizeExchangeRate,
    toBaseAmount,
    assertCashboxCurrency,
} = require('./utils/currencyUtils');
const { reversePaymentInTransaction } = require('./paymentReversalService');

class PaymentController {

    // ─── Internal helpers ─────────────────────────────────────────────────

    async _loadSaleInvoice(db, id) {
        const invoice = await dbGet(db, 'SELECT * FROM sale_invoices WHERE id = ?', [id]);
        if (!invoice) throw { code: 'INVOICE_NOT_PAYABLE', message: 'فاتورة البيع غير موجودة' };
        if (invoice.status === 'draft')     throw { code: 'INVOICE_NOT_PAYABLE', message: 'لا يمكن تسجيل دفعة على فاتورة مسودة' };
        if (invoice.status === 'cancelled') throw { code: 'INVOICE_NOT_PAYABLE', message: 'لا يمكن تسجيل دفعة على فاتورة ملغاة' };
        return invoice;
    }

    async _loadPurchaseInvoice(db, id) {
        const invoice = await dbGet(db, 'SELECT * FROM purchase_invoices WHERE id = ?', [id]);
        if (!invoice) throw { code: 'INVOICE_NOT_PAYABLE', message: 'فاتورة الشراء غير موجودة' };
        if (invoice.status === 'draft')     throw { code: 'INVOICE_NOT_PAYABLE', message: 'لا يمكن تسجيل دفعة على فاتورة مسودة' };
        if (invoice.status === 'cancelled') throw { code: 'INVOICE_NOT_PAYABLE', message: 'لا يمكن تسجيل دفعة على فاتورة ملغاة' };
        return invoice;
    }

    async _loadActiveCashbox(db, cashboxId) {
        const cashbox = await dbGet(db, 'SELECT * FROM cashboxes WHERE id = ?', [cashboxId]);
        if (!cashbox)         throw { code: 'NOT_FOUND', message: 'الصندوق غير موجود' };
        if (!cashbox.isActive) throw { code: 'INVOICE_NOT_PAYABLE', message: 'الصندوق غير نشط' };
        return cashbox;
    }

    async _updateCashboxBalance(db, cashboxId, delta, referenceType, referenceId, txDate, notes) {
        const cashbox = await dbGet(db, 'SELECT balance FROM cashboxes WHERE id = ?', [cashboxId]);
        const balanceBefore = normalizeAmount(cashbox.balance);
        const balanceAfter  = Math.round((balanceBefore + delta) * 100) / 100;

        await dbRun(db,
            `UPDATE cashboxes SET balance = ?, updated_at = datetime('now') WHERE id = ?`,
            [balanceAfter, cashboxId]
        );

        const { lastID } = await dbRun(db,
            `INSERT INTO cashbox_transactions
               (cashbox_id, reference_type, reference_id, amount, direction,
                balance_before, balance_after, transaction_date, notes, created_at, updated_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'), datetime('now'))`,
            [
                cashboxId,
                referenceType,
                referenceId,
                Math.abs(delta),
                delta >= 0 ? 'in' : 'out',
                balanceBefore,
                balanceAfter,
                txDate,
                notes
            ]
        );
        return { lastID, balanceBefore, balanceAfter };
    }

    async _updatePartyBalance(db, partyType, partyId, delta) {
        const table = partyType === 'customer' ? 'customers' : 'suppliers';
        const party = await dbGet(db, `SELECT balance FROM ${table} WHERE id = ?`, [partyId]);
        if (!party) throw { code: 'NOT_FOUND', message: `${partyType === 'customer' ? 'العميل' : 'المورد'} غير موجود` };
        const balanceBefore = normalizeAmount(party.balance);
        const balanceAfter  = Math.round((balanceBefore + delta) * 100) / 100;
        await dbRun(db,
            `UPDATE ${table} SET balance = ?, updated_at = datetime('now') WHERE id = ?`,
            [balanceAfter, partyId]
        );
        return { balanceBefore, balanceAfter };
    }

    async _updateInvoicePaymentState(db, invoiceTable, invoiceId, extraPaid) {
        if (!invoiceId) return null;
        const invoice = await dbGet(db, `SELECT total, paid_amount FROM ${invoiceTable} WHERE id = ?`, [invoiceId]);
        if (!invoice) return null;
        const newPaid   = Math.max(0, Math.round((normalizeAmount(invoice.paid_amount) + extraPaid) * 100) / 100);
        const { remainingAmount, status } = calculatePaymentState(invoice.total, newPaid);
        await dbRun(db,
            `UPDATE ${invoiceTable} SET paid_amount = ?, remaining_amount = ?, status = ?, updated_at = datetime('now') WHERE id = ?`,
            [newPaid, remainingAmount, status, invoiceId]
        );
        return { newPaid, remainingAmount, status };
    }

    // ─── recordSalePayment ────────────────────────────────────────────────

    async recordSalePayment(input) {
        const { sale_invoice_id, cashbox_id, amount, payment_date, notes } = input ?? {};

        if (!sale_invoice_id) throw { code: 'VALIDATION_ERROR', message: 'sale_invoice_id مطلوب' };
        if (!cashbox_id)      throw { code: 'VALIDATION_ERROR', message: 'cashbox_id مطلوب' };
        const validatedAmount = validatePositiveAmount(amount, 'amount');
        const validatedDate   = validateDate(payment_date, 'payment_date');

        const db = await dbmanager.init();

        try {
            await dbRun(db, 'BEGIN TRANSACTION');

            // 1. Load and validate invoice
            const invoice = await this._loadSaleInvoice(db, sale_invoice_id);

            // 2. Load customer (may be null for cash sales)
            const customerId = invoice.customer_id;

            const cashbox = await this._loadActiveCashbox(db, cashbox_id);
            const invoiceCurrency = normalizeCurrency(invoice.currency);
            const invoiceRate = normalizeExchangeRate(invoiceCurrency, invoice.exchange_rate);
            
            let paymentExchangeRate = invoiceRate;
            let cashboxAmount = validatedAmount;
            
            if (cashbox.currency !== invoiceCurrency) {
                if (!input.exchange_rate) {
                    throw { code: 'MISSING_EXCHANGE_RATE', message: 'سعر الصرف مطلوب عند اختلاف عملة الصندوق عن الفاتورة' };
                }
                paymentExchangeRate = normalizeExchangeRate(cashbox.currency, input.exchange_rate);
                // `amount` passed in is the amount in the INVOICE currency.
                // We need to convert it to the CASHBOX currency for the cashbox transaction.
                // Invoice Amount -> Base Amount -> Cashbox Amount
                const amountBaseFromInvoice = toBaseAmount(validatedAmount, invoiceRate);
                cashboxAmount = normalizeAmount(amountBaseFromInvoice / paymentExchangeRate);
            } else {
                paymentExchangeRate = invoiceRate;
            }
            const amountBase = toBaseAmount(cashboxAmount, paymentExchangeRate);

            // 4. Calculate outstanding
            const outstanding = Math.round((normalizeAmount(invoice.total) - normalizeAmount(invoice.paid_amount)) * 100) / 100;
            if (validatedAmount > outstanding + 0.001) {
                throw { code: 'PAYMENT_EXCEEDS_OUTSTANDING', message: `المبلغ (${validatedAmount}) أكبر من المتبقي (${outstanding})` };
            }

            // 5. Create payment record
            const { lastID: paymentId } = await dbRun(db,
                `INSERT INTO payments
                   (party_type, party_id, payment_type, invoice_id, cashbox_id, amount, currency, exchange_rate, amount_base, payment_date,
                    status, notes, created_at, updated_at)
                 VALUES ('customer', ?, 'sale', ?, ?, ?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`,
                [customerId ?? null, sale_invoice_id, cashbox_id, cashboxAmount, cashbox.currency,
                 paymentExchangeRate, amountBase, validatedDate, notes ?? null]
            );

            // 6. Increase cashbox balance
            const cbResult = await this._updateCashboxBalance(
                db, cashbox_id, cashboxAmount, 'sale', sale_invoice_id,
                validatedDate, `دفعة فاتورة بيع #${invoice.invoice_number}`
            );

            // 7. Update payment record with cashbox_transaction_id
            await dbRun(db,
                `UPDATE payments SET cashbox_transaction_id = ? WHERE id = ?`,
                [cbResult.lastID, paymentId]
            );

            // 8. Reduce customer receivable balance (if customer exists)
            let partyBalance = null;
            if (customerId) {
                partyBalance = await this._updatePartyBalance(db, 'customer', customerId, -amountBase);
                await dbRun(db,
                    `UPDATE payments SET balance_before = ?, balance_after = ? WHERE id = ?`,
                    [partyBalance.balanceBefore, partyBalance.balanceAfter, paymentId]
                );
            }

            // 9. Update invoice paid/remaining/status
            await this._updateInvoicePaymentState(db, 'sale_invoices', sale_invoice_id, validatedAmount);

            // 10. Activity log
            await logActivity(db, 'sale_payment_recorded', 'payments', paymentId, {
                sale_invoice_id, amount: validatedAmount, cashbox_id
            });

            await dbRun(db, 'COMMIT');

            // Return enriched data
            const payment = await dbGet(db, 'SELECT * FROM payments WHERE id = ?', [paymentId]);
            const updatedInvoice = await dbGet(db, 'SELECT * FROM sale_invoices WHERE id = ?', [sale_invoice_id]);
            const updatedCashbox = await dbGet(db, 'SELECT * FROM cashboxes WHERE id = ?', [cashbox_id]);
            const customer = customerId ? await dbGet(db, 'SELECT * FROM customers WHERE id = ?', [customerId]) : null;

            return { payment, invoice: updatedInvoice, customer, cashbox: updatedCashbox };

        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            throw err;
        }
    }

    // ─── recordPurchasePayment ────────────────────────────────────────────

    async recordPurchasePayment(input) {
        const { purchase_invoice_id, cashbox_id, amount, payment_date, notes } = input ?? {};

        if (!purchase_invoice_id) throw { code: 'VALIDATION_ERROR', message: 'purchase_invoice_id مطلوب' };
        if (!cashbox_id)          throw { code: 'VALIDATION_ERROR', message: 'cashbox_id مطلوب' };
        const validatedAmount = validatePositiveAmount(amount, 'amount');
        const validatedDate   = validateDate(payment_date, 'payment_date');

        const db = await dbmanager.init();

        try {
            await dbRun(db, 'BEGIN TRANSACTION');

            // 1. Load and validate invoice
            const invoice = await this._loadPurchaseInvoice(db, purchase_invoice_id);
            const supplierId = invoice.supplier_id;

            // 2. Load and validate cashbox
            const cashbox = await this._loadActiveCashbox(db, cashbox_id);
            const invoiceCurrency = normalizeCurrency(invoice.currency);
            const invoiceRate = normalizeExchangeRate(invoiceCurrency, invoice.exchange_rate);
            
            let paymentExchangeRate = invoiceRate;
            let cashboxAmount = validatedAmount;
            
            if (cashbox.currency !== invoiceCurrency) {
                if (!input.exchange_rate) {
                    throw { code: 'MISSING_EXCHANGE_RATE', message: 'سعر الصرف مطلوب عند اختلاف عملة الصندوق عن الفاتورة' };
                }
                paymentExchangeRate = normalizeExchangeRate(cashbox.currency, input.exchange_rate);
                const amountBaseFromInvoice = toBaseAmount(validatedAmount, invoiceRate);
                cashboxAmount = normalizeAmount(amountBaseFromInvoice / paymentExchangeRate);
            } else {
                paymentExchangeRate = invoiceRate;
            }
            const amountBase = toBaseAmount(cashboxAmount, paymentExchangeRate);

            // 3. Check cashbox balance sufficient
            const cashboxBalance = normalizeAmount(cashbox.balance);
            if (cashboxBalance < cashboxAmount - 0.001) {
                throw { code: 'INSUFFICIENT_BALANCE', message: `رصيد الصندوق (${cashboxBalance}) أقل من المبلغ المطلوب (${cashboxAmount})` };
            }

            // 4. Calculate outstanding
            const outstanding = Math.round((normalizeAmount(invoice.total) - normalizeAmount(invoice.paid_amount)) * 100) / 100;
            if (validatedAmount > outstanding + 0.001) {
                throw { code: 'PAYMENT_EXCEEDS_OUTSTANDING', message: `المبلغ (${validatedAmount}) أكبر من المتبقي (${outstanding})` };
            }

            // 5. Create payment record
            const { lastID: paymentId } = await dbRun(db,
                `INSERT INTO payments
                   (party_type, party_id, payment_type, invoice_id, cashbox_id, amount, currency, exchange_rate, amount_base, payment_date,
                    status, notes, created_at, updated_at)
                 VALUES ('supplier', ?, 'purchase', ?, ?, ?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`,
                [supplierId, purchase_invoice_id, cashbox_id, cashboxAmount, cashbox.currency,
                 paymentExchangeRate, amountBase, validatedDate, notes ?? null]
            );

            // 6. Deduct cashbox balance (negative delta)
            const cbResult = await this._updateCashboxBalance(
                db, cashbox_id, -cashboxAmount, 'purchase', purchase_invoice_id,
                validatedDate, `دفعة فاتورة شراء #${invoice.invoice_number}`
            );

            // 7. Update payment with cashbox_transaction_id
            await dbRun(db,
                `UPDATE payments SET cashbox_transaction_id = ? WHERE id = ?`,
                [cbResult.lastID, paymentId]
            );

            // 8. Reduce supplier payable balance
            const partyBalance = await this._updatePartyBalance(db, 'supplier', supplierId, -amountBase);
            await dbRun(db,
                `UPDATE payments SET balance_before = ?, balance_after = ? WHERE id = ?`,
                [partyBalance.balanceBefore, partyBalance.balanceAfter, paymentId]
            );

            // 9. Update invoice paid/remaining/status
            await this._updateInvoicePaymentState(db, 'purchase_invoices', purchase_invoice_id, validatedAmount);

            // 10. Activity log
            await logActivity(db, 'purchase_payment_recorded', 'payments', paymentId, {
                purchase_invoice_id, amount: validatedAmount, cashbox_id
            });

            await dbRun(db, 'COMMIT');

            const payment = await dbGet(db, 'SELECT * FROM payments WHERE id = ?', [paymentId]);
            const updatedInvoice = await dbGet(db, 'SELECT * FROM purchase_invoices WHERE id = ?', [purchase_invoice_id]);
            const updatedCashbox = await dbGet(db, 'SELECT * FROM cashboxes WHERE id = ?', [cashbox_id]);
            const supplier = await dbGet(db, 'SELECT * FROM suppliers WHERE id = ?', [supplierId]);

            return { payment, invoice: updatedInvoice, supplier, cashbox: updatedCashbox };

        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            throw err;
        }
    }

    // ─── recordGeneralReceipt ──────────────────────────────────────────────
    
    async recordGeneralReceipt(input) {
        const { party_type, party_id, cashbox_id, amount, payment_date, notes } = input ?? {};

        if (!party_type) throw { code: 'VALIDATION_ERROR', message: 'party_type مطلوب' };
        if (!party_id) throw { code: 'VALIDATION_ERROR', message: 'party_id مطلوب' };
        if (!cashbox_id) throw { code: 'VALIDATION_ERROR', message: 'cashbox_id مطلوب' };
        const validatedAmount = validatePositiveAmount(amount, 'amount');
        const validatedDate = validateDate(payment_date, 'payment_date');

        const db = await dbmanager.init();

        try {
            await dbRun(db, 'BEGIN TRANSACTION');

            const cashbox = await this._loadActiveCashbox(db, cashbox_id);
            
            const paymentExchangeRate = input.exchange_rate ? normalizeExchangeRate(cashbox.currency, input.exchange_rate) : 1;
            const amountBase = toBaseAmount(validatedAmount, paymentExchangeRate);

            // 1. Create payment record
            const { lastID: paymentId } = await dbRun(db,
                `INSERT INTO payments
                   (party_type, party_id, payment_type, invoice_id, cashbox_id, amount, currency, exchange_rate, amount_base, payment_date,
                    status, notes, created_at, updated_at)
                 VALUES (?, ?, 'general_receipt', NULL, ?, ?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`,
                [party_type, party_id, cashbox_id, validatedAmount, cashbox.currency,
                 paymentExchangeRate, amountBase, validatedDate, notes ?? null]
            );

            // 2. Increase cashbox balance (receipt = IN)
            const cbResult = await this._updateCashboxBalance(
                db, cashbox_id, validatedAmount, 'income', paymentId,
                validatedDate, `سند قبض عام - ${party_type === 'customer' ? 'عميل' : 'مورد'} #${party_id}`
            );

            // 3. Update payment record with cashbox_transaction_id
            await dbRun(db,
                `UPDATE payments SET cashbox_transaction_id = ? WHERE id = ?`,
                [cbResult.lastID, paymentId]
            );

            // 4. Update party balance
            // Customer: reduces their receivable balance (-amount)
            // Supplier: increases their payable balance (+amount) (e.g. they refunded us)
            const partyDelta = party_type === 'customer' ? -amountBase : amountBase;
            const partyBalance = await this._updatePartyBalance(db, party_type, party_id, partyDelta);

            await dbRun(db,
                `UPDATE payments SET balance_before = ?, balance_after = ? WHERE id = ?`,
                [partyBalance.balanceBefore, partyBalance.balanceAfter, paymentId]
            );

            // 5. Activity log
            await logActivity(db, 'general_receipt_recorded', 'payments', paymentId, {
                party_type, party_id, amount: validatedAmount, cashbox_id
            });

            await dbRun(db, 'COMMIT');

            const payment = await dbGet(db, 'SELECT * FROM payments WHERE id = ?', [paymentId]);
            const updatedCashbox = await dbGet(db, 'SELECT * FROM cashboxes WHERE id = ?', [cashbox_id]);
            const partyTable = party_type === 'customer' ? 'customers' : 'suppliers';
            const party = await dbGet(db, `SELECT * FROM ${partyTable} WHERE id = ?`, [party_id]);

            return { payment, party, cashbox: updatedCashbox };

        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            throw err;
        }
    }

    // ─── recordGeneralPayment ──────────────────────────────────────────────

    async recordGeneralPayment(input) {
        const { party_type, party_id, cashbox_id, amount, payment_date, notes } = input ?? {};

        if (!party_type) throw { code: 'VALIDATION_ERROR', message: 'party_type مطلوب' };
        if (!party_id) throw { code: 'VALIDATION_ERROR', message: 'party_id مطلوب' };
        if (!cashbox_id) throw { code: 'VALIDATION_ERROR', message: 'cashbox_id مطلوب' };
        const validatedAmount = validatePositiveAmount(amount, 'amount');
        const validatedDate = validateDate(payment_date, 'payment_date');

        const db = await dbmanager.init();

        try {
            await dbRun(db, 'BEGIN TRANSACTION');

            const cashbox = await this._loadActiveCashbox(db, cashbox_id);
            
            // Check cashbox balance sufficient
            const cashboxBalance = normalizeAmount(cashbox.balance);
            if (cashboxBalance < validatedAmount - 0.001) {
                throw { code: 'INSUFFICIENT_BALANCE', message: `رصيد الصندوق (${cashboxBalance}) أقل من المبلغ المطلوب (${validatedAmount})` };
            }

            const paymentExchangeRate = input.exchange_rate ? normalizeExchangeRate(cashbox.currency, input.exchange_rate) : 1;
            const amountBase = toBaseAmount(validatedAmount, paymentExchangeRate);

            // 1. Create payment record
            const { lastID: paymentId } = await dbRun(db,
                `INSERT INTO payments
                   (party_type, party_id, payment_type, invoice_id, cashbox_id, amount, currency, exchange_rate, amount_base, payment_date,
                    status, notes, created_at, updated_at)
                 VALUES (?, ?, 'general_payment', NULL, ?, ?, ?, ?, ?, ?, 'active', ?, datetime('now'), datetime('now'))`,
                [party_type, party_id, cashbox_id, validatedAmount, cashbox.currency,
                 paymentExchangeRate, amountBase, validatedDate, notes ?? null]
            );

            // 2. Decrease cashbox balance (payment = OUT)
            const cbResult = await this._updateCashboxBalance(
                db, cashbox_id, -validatedAmount, 'expense', paymentId,
                validatedDate, `سند دفع عام - ${party_type === 'customer' ? 'عميل' : 'مورد'} #${party_id}`
            );

            // 3. Update payment record with cashbox_transaction_id
            await dbRun(db,
                `UPDATE payments SET cashbox_transaction_id = ? WHERE id = ?`,
                [cbResult.lastID, paymentId]
            );

            // 4. Update party balance
            // Supplier: decreases their payable balance (-amount)
            // Customer: increases their receivable balance (+amount) (e.g. we refunded them)
            const partyDelta = party_type === 'supplier' ? -amountBase : amountBase;
            const partyBalance = await this._updatePartyBalance(db, party_type, party_id, partyDelta);

            await dbRun(db,
                `UPDATE payments SET balance_before = ?, balance_after = ? WHERE id = ?`,
                [partyBalance.balanceBefore, partyBalance.balanceAfter, paymentId]
            );

            // 5. Activity log
            await logActivity(db, 'general_payment_recorded', 'payments', paymentId, {
                party_type, party_id, amount: validatedAmount, cashbox_id
            });

            await dbRun(db, 'COMMIT');

            const payment = await dbGet(db, 'SELECT * FROM payments WHERE id = ?', [paymentId]);
            const updatedCashbox = await dbGet(db, 'SELECT * FROM cashboxes WHERE id = ?', [cashbox_id]);
            const partyTable = party_type === 'customer' ? 'customers' : 'suppliers';
            const party = await dbGet(db, `SELECT * FROM ${partyTable} WHERE id = ?`, [party_id]);

            return { payment, party, cashbox: updatedCashbox };

        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            throw err;
        }
    }

    // ─── reverseSalePayment ───────────────────────────────────────────────

    async reverseSalePayment(paymentId, reason, userId = null) {
        const db = await dbmanager.init();
        try {
            await dbRun(db, 'BEGIN IMMEDIATE TRANSACTION');
            const result = await reversePaymentInTransaction(db, {
                paymentId,
                expectedType: 'sale',
                reason,
                userId,
            });
            await dbRun(db, 'COMMIT');
            return result;
        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            console.error('[payment-reversal:sale]', {
                paymentId,
                code: err?.code,
                message: err?.message,
            });
            throw err?.code ? err : { code: 'PAYMENT_REVERSAL_FAILED', message: 'تعذر عكس دفعة البيع', details: err?.message };
        }
    }

    // ─── reversePurchasePayment ───────────────────────────────────────────

    async reversePurchasePayment(paymentId, reason, userId = null) {
        const db = await dbmanager.init();
        try {
            await dbRun(db, 'BEGIN IMMEDIATE TRANSACTION');
            const result = await reversePaymentInTransaction(db, {
                paymentId,
                expectedType: 'purchase',
                reason,
                userId,
            });
            await dbRun(db, 'COMMIT');
            return result;
        } catch (err) {
            await new Promise((res) => db.run('ROLLBACK', () => res()));
            console.error('[payment-reversal:purchase]', {
                paymentId,
                code: err?.code,
                message: err?.message,
            });
            throw err?.code ? err : { code: 'PAYMENT_REVERSAL_FAILED', message: 'تعذر عكس دفعة الشراء', details: err?.message };
        }
    }

    // ─── Read-only queries ────────────────────────────────────────────────

    async getSalePayments(invoiceId) {
        if (!invoiceId) throw { code: 'VALIDATION_ERROR', message: 'invoiceId مطلوب' };
        const db = await dbmanager.init();
        return dbAll(db,
            `SELECT p.*, c.name as cashbox_name, cu.name as customer_name
             FROM payments p
             LEFT JOIN cashboxes c ON p.cashbox_id = c.id
             LEFT JOIN customers cu ON p.party_type = 'customer' AND p.party_id = cu.id
             WHERE p.invoice_id = ? AND p.payment_type = 'sale'
             ORDER BY p.payment_date DESC, p.id DESC`,
            [invoiceId]
        );
    }

    async getPurchasePayments(invoiceId) {
        if (!invoiceId) throw { code: 'VALIDATION_ERROR', message: 'invoiceId مطلوب' };
        const db = await dbmanager.init();
        return dbAll(db,
            `SELECT p.*, c.name as cashbox_name, su.name as supplier_name
             FROM payments p
             LEFT JOIN cashboxes c ON p.cashbox_id = c.id
             LEFT JOIN suppliers su ON p.party_type = 'supplier' AND p.party_id = su.id
             WHERE p.invoice_id = ? AND p.payment_type = 'purchase'
             ORDER BY p.payment_date DESC, p.id DESC`,
            [invoiceId]
        );
    }

    async getPayment(id) {
        if (!id) throw { code: 'VALIDATION_ERROR', message: 'ID مطلوب' };
        const db = await dbmanager.init();
        const row = await dbGet(db,
            `SELECT p.*, c.name as cashbox_name, cu.name as customer_name, su.name as supplier_name
             FROM payments p 
             LEFT JOIN cashboxes c ON p.cashbox_id = c.id 
             LEFT JOIN customers cu ON p.party_type = 'customer' AND p.party_id = cu.id
             LEFT JOIN suppliers su ON p.party_type = 'supplier' AND p.party_id = su.id
             WHERE p.id = ?`,
            [id]
        );
        if (!row) throw { code: 'NOT_FOUND', message: 'الدفعة غير موجودة' };
        return row;
    }

    async getPartyPayments(partyType, partyId) {
        if (!partyType || !partyId) throw { code: 'VALIDATION_ERROR', message: 'partyType و partyId مطلوبان' };
        const db = await dbmanager.init();
        return dbAll(db,
            `SELECT p.*, c.name as cashbox_name, cu.name as customer_name, su.name as supplier_name
             FROM payments p
             LEFT JOIN cashboxes c ON p.cashbox_id = c.id
             LEFT JOIN customers cu ON p.party_type = 'customer' AND p.party_id = cu.id
             LEFT JOIN suppliers su ON p.party_type = 'supplier' AND p.party_id = su.id
             WHERE p.party_type = ? AND p.party_id = ?
             ORDER BY p.payment_date DESC, p.id DESC`,
            [partyType, partyId]
        );
    }

    async getAllPayments() {
        const db = await dbmanager.init();
        return dbAll(db, `
            SELECT p.*, 
                   cu.name as customer_name,
                   su.name as supplier_name
            FROM payments p 
            LEFT JOIN customers cu ON p.party_type = 'customer' AND p.party_id = cu.id
            LEFT JOIN suppliers su ON p.party_type = 'supplier' AND p.party_id = su.id
            ORDER BY p.created_at DESC
        `);
    }
}

module.exports = new PaymentController();
